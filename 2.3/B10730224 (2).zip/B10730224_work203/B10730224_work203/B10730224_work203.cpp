﻿// B10730224_work203.cpp : 此檔案包含 'main' 函式。程式會於該處開始執行及結束執行。
//

#include "pch.h"
#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
	float in;
	float tax;
	while (cin >> in) {
		if (in < 0)
			continue;
		if (in <= 750) {
			tax = in * 0.01;
		}
		else if (in <= 2250) {
			in -= 750;
			tax = 7.50 + in * 0.02;
		}
		else if (in <= 3750) {
			in -= 2250;
			tax = 37.50 + in * 0.03;
		}
		else if(in <= 5250) {
			in -= 3750;
			tax = 82.50 + in * 0.04;
		}
		else if (in <= 7000) {
			in -= 5250;
			tax = 142.50 + in * 0.05;
		}
		else{
			in -= 7000;
			tax = 230.00 + in * 0.06;
		}
		cout << fixed << setprecision(2) << tax << endl;
	}
}

// 執行程式: Ctrl + F5 或 [偵錯] > [啟動但不偵錯] 功能表
// 偵錯程式: F5 或 [偵錯] > [啟動偵錯] 功能表

// 開始使用的秘訣: 
//   1. 使用 [方案總管] 視窗，新增/管理檔案
//   2. 使用 [Team Explorer] 視窗，連線到原始檔控制
//   3. 使用 [輸出] 視窗，參閱組建輸出與其他訊息
//   4. 使用 [錯誤清單] 視窗，檢視錯誤
//   5. 前往 [專案] > [新增項目]，建立新的程式碼檔案，或是前往 [專案] > [新增現有項目]，將現有程式碼檔案新增至專案
//   6. 之後要再次開啟此專案時，請前往 [檔案] > [開啟] > [專案]，然後選取 .sln 檔案
