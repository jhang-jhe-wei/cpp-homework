﻿// B10730224_WORK502.cpp : 此檔案包含 'main' 函式。程式會於該處開始執行及結束執行。
//

#include "pch.h"
#include <iostream>
#include <string>
using namespace std;
class Atoi {

private:

	string beTrans;

	char sign;

public:

	Atoi();

	Atoi(string s);

	void SetString(string s);

	int Length();

	bool IsDigital();

	int StringToInteger();

};

int main(void) {

	string beTrans;
	while (cin >> beTrans) {
		Atoi atoi(beTrans + "20");		
		if (atoi.IsDigital()) {
			cout << atoi.Length() << endl;
			cout << atoi.StringToInteger() << endl;
			cout << sizeof(atoi.StringToInteger()) << endl;
		}
		cout << "---- - " << endl;
		atoi.SetString(beTrans);
		if (atoi.IsDigital()) {
			cout << atoi.Length() << endl;
			cout << atoi.StringToInteger() << endl;
			cout << sizeof(atoi.StringToInteger()) << endl;
		}
		cout << "---- - " << endl;
	}
	return 0;
}


// 執行程式: Ctrl + F5 或 [偵錯] > [啟動但不偵錯] 功能表
// 偵錯程式: F5 或 [偵錯] > [啟動偵錯] 功能表

// 開始使用的秘訣: 
//   1. 使用 [方案總管] 視窗，新增/管理檔案
//   2. 使用 [Team Explorer] 視窗，連線到原始檔控制
//   3. 使用 [輸出] 視窗，參閱組建輸出與其他訊息
//   4. 使用 [錯誤清單] 視窗，檢視錯誤
//   5. 前往 [專案] > [新增項目]，建立新的程式碼檔案，或是前往 [專案] > [新增現有項目]，將現有程式碼檔案新增至專案
//   6. 之後要再次開啟此專案時，請前往 [檔案] > [開啟] > [專案]，然後選取 .sln 檔案

Atoi::Atoi()
{
	beTrans.clear();
	sign = '+';
}

Atoi::Atoi(string s) 
{
	beTrans.clear();
	sign = '+';
	if (s.at(0)=='-') 
	{
		sign = '-';
		s.erase(0,1);
	}
	beTrans = s;	
}

void Atoi::SetString(string s)
{
	beTrans.clear();
	sign = '+';
	if (s.at(0) == '-')
	{
		sign = '-';
		s.erase(0,1);
	}
	beTrans = s;	
}

int Atoi::Length() 
{
	return beTrans.size();
}

bool Atoi::IsDigital()
{
	for (int i = 0; i < beTrans.size(); i++) 
	{
		if (beTrans.at(i) < 48 || beTrans.at(i) > 57) 
		{
			return false;
		}
	}
	return true;
}

int Atoi::StringToInteger()
{
	int result=0;
	for (int i = 0; i < beTrans.size(); i++) 
	{
		result *= 10;
		result += beTrans.at(i) - 48;		
	}
	if (sign == '-') 
	{
		result *= -1;
	}
	return result;
}
