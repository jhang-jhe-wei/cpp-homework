//Author:wells
//Date:2019/4/10
//Last Updata:2019/4/10
//Problem statement:Creature a monster
#include "Diary.h"
string Diary::day;
void Diary::NewDay(string day)
{	
	Diary::day = day;
}

