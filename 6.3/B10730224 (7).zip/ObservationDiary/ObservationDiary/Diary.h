//Author:wells
//Date:2019/4/10
//Last Updata:2019/4/10
//Problem statement:Creature a monster
#pragma once
#include <string>
using namespace std;
class Diary
{
public:	
	static void NewDay(string day);	
	static string day;
};

