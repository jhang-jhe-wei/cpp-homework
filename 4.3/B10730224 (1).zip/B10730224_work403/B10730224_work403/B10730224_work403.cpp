﻿// B10730224_work403.cpp : 此檔案包含 'main' 函式。程式會於該處開始執行及結束執行。
//

#include "pch.h"
#include <iostream>
#include <string>
#include <vector>
using namespace std;
typedef struct {
	char firstName[25];
	char lastName[30];
	char phone[15];
} StRec;

int main()
{
	string mode;
	string firstName;
	string lastName;
	string phone;
	vector<StRec> data;
	bool error = false;
	while (cin >> mode )
	{
		
		if (mode == "print") 
		{
			if (data.empty()) 
			{
				cout << "Print Error" << endl;
			}
			else 
			{
				for (int i = 0; i < data.size(); i++) 
				{
					cout << data.at(i).firstName << ' ' << data.at(i).lastName << ' ' << data.at(i).phone << endl;
				}
			}
		}
		else 
		{
			cin >> firstName >> lastName >> phone;
			error = false;
			if (firstName.size() > 25 || lastName.size() > 30 || phone.size() > 15)
			{
				cout << "Input Error" << endl;
				continue;
			}
			for (int i = 0; i < phone.size(); i++)
			{
				int tmp = (int)phone[i];
				if (tmp >= 48 && tmp <= 57)
				{
					continue;
				}
				else
				{
					cout << "Input Error" << endl;
					error = true;
					break;
				}
			}
			if (error)
			{
				continue;
			}
			if (mode == "insert")
			{
				if (data.size() >= 10)
				{
					cout << "Insert Error" << endl;
					continue;
				}
				for (int i = 0; i < data.size(); i++) {
					if (data.at(i).firstName == firstName && data.at(i).lastName == lastName && data.at(i).phone == phone)
					{
						cout << "Insert Error" << endl;
						error = true;
						break;
					}
				}
				if (error)
				{
					continue;
				}
				StRec model;
				strncpy_s(model.firstName, firstName.c_str(), firstName.length() + 1);
				strncpy_s(model.lastName, lastName.c_str(), lastName.length() + 1);
				strncpy_s(model.phone, phone.c_str(), phone.length() + 1);
				data.push_back(model);
			}
			else if (mode == "search")
			{
				for (int i = 0; i < data.size(); i++) {
					if (data.at(i).firstName == firstName && data.at(i).lastName == lastName && data.at(i).phone == phone)
					{
						cout << i << endl;
						error = true;
					}					
				}
				if (error)
				{
					continue;
				}
				cout << "Search Error" << endl;
			}
			else if (mode == "delete")
			{
				for (int i = 0; i < data.size(); i++) {
					if (data.at(i).firstName == firstName && data.at(i).lastName == lastName && data.at(i).phone == phone)
					{
						data.erase(data.begin() + i);
						error = true;
					}					
				}
				if (error)
				{
					continue;
				}
				cout << "Delete Error" << endl;
			}
			else
			{
				cout << "Input Error" << endl;
				continue;
			}
		}
		
	}
}

// 執行程式: Ctrl + F5 或 [偵錯] > [啟動但不偵錯] 功能表
// 偵錯程式: F5 或 [偵錯] > [啟動偵錯] 功能表

// 開始使用的秘訣: 
//   1. 使用 [方案總管] 視窗，新增/管理檔案
//   2. 使用 [Team Explorer] 視窗，連線到原始檔控制
//   3. 使用 [輸出] 視窗，參閱組建輸出與其他訊息
//   4. 使用 [錯誤清單] 視窗，檢視錯誤
//   5. 前往 [專案] > [新增項目]，建立新的程式碼檔案，或是前往 [專案] > [新增現有項目]，將現有程式碼檔案新增至專案
//   6. 之後要再次開啟此專案時，請前往 [檔案] > [開啟] > [專案]，然後選取 .sln 檔案
